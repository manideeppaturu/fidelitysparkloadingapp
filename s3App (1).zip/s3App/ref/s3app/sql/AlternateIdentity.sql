
create table "AlternateIdentity"
(
	"IndividualID" int4 NOT NULL,
	"IdentityIssuer" varchar(100) NULL,
	"IdentityType" varchar(100) NULL,
	"IdentityValue" varchar(100) NULL,
	CONSTRAINT "AlternateIdentity_pkey" PRIMARY KEY ("IndividualID")
);

select * from "AlternateIdentity" where "IndividualID"=8

