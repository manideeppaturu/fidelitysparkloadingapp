CREATE TABLE public."ProductIndividualRelationship"(
	"IndividualProductID" int4 NOT NULL,
	"IndividualID" int4 NOT NULL,
	"ProductID" int4 NOT NULL,
	"RelationshipStatus" varchar(1) NULL,
	CONSTRAINT "ProductIndividualRelationship_pkey" PRIMARY KEY ("IndividualProductID"),
	CONSTRAINT "fk_ProductIndividualRelationship_Individual_1" FOREIGN KEY ("IndividualID") REFERENCES public."Individual"("IndividualID") ON DELETE RESTRICT
	);
	
ALTER TABLE public."ProductIndividualRelationship" OWNER TO jaggu;
GRANT ALL ON TABLE public."ProductIndividualRelationship" TO jaggu;