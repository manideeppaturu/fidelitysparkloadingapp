INSERT INTO public."SourceSystem"
("SourceSystemID","SourceSystemName")
VALUES(1,'bSolo_DB');
INSERT INTO public."SourceSystem"
("SourceSystemID","SourceSystemName")
VALUES(2,'cSolo_DB');
INSERT INTO public."SourceSystem"
("SourceSystemID","SourceSystemName")
VALUES(3,'dSolo_DB');