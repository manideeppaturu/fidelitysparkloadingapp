CREATE TABLE public."SourceSystemXREF"(
	"IndividualID" int4 NOT NULL,
	"SourceSystemID" int4 NOT NULL,
	"SourceSystemRefereceValue" varchar(255) NULL,
	CONSTRAINT "SourceSystemXREF_pkey" PRIMARY KEY ("IndividualID","SourceSystemID"),
	CONSTRAINT "fk_SourceSystemXREF_Individual_1" FOREIGN KEY ("IndividualID") REFERENCES public."Individual"("IndividualID") ON DELETE CASCADE,
	CONSTRAINT "fk_SourceSystemXREF_SourceSystem_1" FOREIGN KEY ("SourceSystemID") REFERENCES public."SourceSystem"("SourceSystemID") ON DELETE CASCADE
	);
	
ALTER TABLE public."SourceSystemXREF" OWNER TO jaggu;
GRANT ALL ON TABLE public."SourceSystemXREF" TO jaggu;