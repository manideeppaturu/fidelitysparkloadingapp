CREATE TABLE public."SourceSystem"(
	"SourceSystemID" int4 NOT NULL,
	"SourceSystemName" varchar(255) NOT NULL,
	CONSTRAINT "SourceSystem_pkey" PRIMARY KEY ("SourceSystemID"),
	);
	
