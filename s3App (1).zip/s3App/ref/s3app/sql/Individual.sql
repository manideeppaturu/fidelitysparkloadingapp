
create table "Individual"
(
	"IndividualID" int4 NOT NULL,
	"NamePrefix" varchar(100) NULL,
	"FirstName" varchar(255) NULL,
	"MiddleName" varchar(255) NULL,
	"LastName" varchar(255) NULL,
	"NameSuffix" varchar(100) NULL,
	"Gender" varchar(1) NULL,
	"BirthYear" varchar(4) NULL,
	"BirthMonth" varchar(2) NULL,
	"IndividualLast4ID" varchar(4) NULL,
	"FingerPrint" varchar(2000) NULL,
	CONSTRAINT "Individual_pkey" PRIMARY KEY ("IndividualID")
);

select * from "Individual" where "IndividualID"=8
