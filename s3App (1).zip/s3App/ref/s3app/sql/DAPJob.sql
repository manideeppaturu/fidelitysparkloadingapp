CREATE TABLE public."DAPJob"(
	"DAPJobID" serial NOT NULL,
	"SourceSystemID" int4 NOT NULL,
	"SourceType" varchar(100) NOT NULL,
	"SourceItem" varchar(255) NOT NULL,
	"JobType" varchar(100) NOT NULL,
	"LastRunTimeStamp" timestamptz NULL,
	"JobStatus" varchar(100)  NULL,
	CONSTRAINT "DAPJob_pkey" PRIMARY KEY ("DAPJobID"),
	CONSTRAINT "fk_DAPJob_SourceSystem_1" FOREIGN KEY ("SourceSystemID") REFERENCES public."SourceSystem"("SourceSystemID") ON DELETE RESTRICT
	);
	
	
ALTER TABLE public."DAPJob" OWNER TO jaggu;
GRANT ALL ON TABLE public."DAPJob" TO jaggu;

 
 insert into public."DAPJob" 
( "SourceSystemID", "SourceType", "SourceItem" , "JobType", "LastRunTimeStamp", "JobStatus" )
values 
(1,'DB','user','Inbound',to_timestamp('2019-02-08 15:36:38', 'yyyy-mm-dd hh24:mi:ss'), 'SUCCESS');


 insert into public."DAPJob" 
( "SourceSystemID", "SourceType", "SourceItem" , "JobType", "LastRunTimeStamp", "JobStatus" )
values 
(2,'DB','user_info','Inbound',TIMESTAMP '2019-02-09 15:36:38', 'SUCCESS');


 insert into public."DAPJob" 
( "SourceSystemID", "SourceType", "SourceItem" , "JobType", "LastRunTimeStamp", "JobStatus" )
values 
(3,'DB','cars','Inbound',to_timestamp('2019-02-10 15:36:38', 'yyyy-mm-dd hh24:mi:ss'), 'FAILURE');


 insert into public."DAPJob" 
( "SourceSystemID", "SourceType", "SourceItem" , "JobType", "LastRunTimeStamp", "JobStatus" )
values 
(4,'DB','product','Inbound',to_timestamp('2019-02-11 15:36:38', 'yyyy-mm-dd hh24:mi:ss'), 'FAILURE');
