

delete from public."ProductIndividualRelationship";
delete from public."Individual";
delete from public."AlternateIdentity";
delete from public."SourceSystemXREF";

