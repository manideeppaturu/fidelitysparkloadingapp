CREATE TABLE public."IndividualBankAccount"(
	"BankAccountID" int4 NOT NULL,
	"IndividualProductID" int4 NOT NULL,
	"AccountType" varchar(255) NULL,
	"BankName" varchar(255) NULL,
	"BankAccountName" varchar(255) NULL,
	"IsActive" varchar(1) NULL,
	"IsLinkBroken" varchar(255) NULL,
	"3rdPartyAccRefID" varchar(255) NULL,
	CONSTRAINT "IndividualBankAccount_pkey" PRIMARY KEY ("BankAccountID")
	);
	
