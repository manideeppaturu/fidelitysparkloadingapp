{
	"source":"product.dat",
	"columns":[
				"user_id",
				"product_id",
				"individual_product_id"
			  ]
}