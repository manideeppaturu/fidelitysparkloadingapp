{
	"source":"user.dat",
	"columns":[
				"user_id",
				"email"
			  ]
}