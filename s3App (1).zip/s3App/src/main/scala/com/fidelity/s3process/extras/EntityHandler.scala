package com.fidelity.s3process.extras

import org.apache.spark.sql.Dataset
import org.apache.spark.sql.Row
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.row_number

import com.fidelity.s3process.util.JdbcAppUtils
import com.fidelity.s3process.util.JsonUtils.MappingData
import com.fidelity.s3process.util.JsonUtils.ReferenceMappingData
import com.fidelity.s3process.util.PropertyUtils
import com.fidelity.s3process.util.SparkUtils
import com.fidelity.s3process.util.NamesUtil
import com.fidelity.s3process.util.S3Util

object EntityHandler {

  case class HoldSeq(id: Long)

  val specialEntities: Array[String] = Array("Individual")

  def isSpecialCase(mappingData: MappingData): Boolean = {
    val entryExists: Boolean = specialEntities.contains(mappingData.tableName)
    entryExists
  }

  def handleEntity(spark: SparkSession, targetName: String, mappingData: MappingData, operation: String): Unit = {

    val entity: String = mappingData.tableName
    val sourceSystemName = NamesUtil.getSourceSystemName(targetName)
    val sourceNamePrefix = NamesUtil.getSourceNamePrefix(targetName)
    val primarySourceName: String = sourceNamePrefix + mappingData.primarySource
    
    if (entity == "Individual") {
      
      val referenceMappingData: ReferenceMappingData = SparkUtils.getReferenceMappingData(targetName)
      val primaySourceKeyQN: String = mappingData.primarySource + "__" + mappingData.primarySourceKey
      val childName: String = sourceNamePrefix + referenceMappingData.childTableName
      val childMappingData: MappingData = SparkUtils.getMappingData(childName)
      val childTableDF = SparkUtils.getJdbcTableDF(spark, childMappingData)
      childTableDF.cache()
      val childTableRefKeyDF = childTableDF.select(referenceMappingData.childTableRefKey)
      val childTable = referenceMappingData.childTableName
      var childTableForRejectModelDF = childTableDF.select(referenceMappingData.childTablePrimaryKey, referenceMappingData.childTableRefKey)
      childTableForRejectModelDF = childTableForRejectModelDF.toDF(childTableForRejectModelDF.columns.map(column=>childTable+"__"+column):_*)
      println("childTableForRejectModelDF : ")
      childTableForRejectModelDF.show()
      
      val pushTable: String = referenceMappingData.pushTable
      val pushTableName: String = sourceNamePrefix + pushTable
      val pushTableMappingData: MappingData = SparkUtils.getMappingData(pushTableName)
      val pushTableDF = SparkUtils.getJdbcTableDF(spark, pushTableMappingData)
      pushTableDF.cache()
      var pushTableForRejectModelDF = pushTableDF.select(referenceMappingData.childTablePrimaryKey, referenceMappingData.pushTableRefKey)
      pushTableForRejectModelDF = pushTableForRejectModelDF.toDF(pushTableForRejectModelDF.columns.map(column=>pushTable+"__"+column):_*)
      println("pushTableForRejectModelDF : ")
      pushTableForRejectModelDF.show()
      
      var sourceDF = SparkUtils.createEmptyDataframe(spark, targetName, mappingData.primarySource)
      var sourceRejectDF = SparkUtils.createEmptyDataframe(spark, targetName, mappingData.primarySource)
      val sourceList: Array[String] = mappingData.sourceList
      val s3SourcesList: List[String] = S3Util.getS3MatchingFileKeys(
                                                  PropertyUtils.getProperty("sourceDataBucketName"),
                                                  PropertyUtils.getProperty("sourceDataFolderKey") + "/" + primarySourceName,
                                                  ".dat"
                                                )

      for (s3SourceFileNameKey <- s3SourcesList) {
        val s3SourceFileName: String = s3SourceFileNameKey.replaceFirst(PropertyUtils.getProperty("sourceDataFolderKey") + "/", "")
        println("Processing source file : " + s3SourceFileName)
        var s3SourceDF = SparkUtils.getSourceDF(spark, targetName, mappingData.primarySource, s3SourceFileName)
        println("Displaying sourceDF from S3 : ")
        s3SourceDF.show()
        // pick rejectDFs and check for any matching records
        SparkUtils.checkAndProcessPreviousRejectedRecords(spark, targetName, mappingData.primarySource, s3SourceDF)
        
        var rejectDF = SparkUtils.getDataTypeMismatchRecords(s3SourceDF, mappingData)
        val childTableDataForRejectRefDF = childTableForRejectModelDF.join(s3SourceDF, s3SourceDF.col(referenceMappingData.sourceRefKey) === childTableForRejectModelDF.col(childTable+"__"+referenceMappingData.childTableRefKey), "left_semi")        
        println("showing childTableDataForRejectRefDF : ")
        childTableDataForRejectRefDF.show()
        val childAndPushTableDataForRejectRefDF = childTableDataForRejectRefDF
                                                  .join(pushTableForRejectModelDF,
                                                        childTableDataForRejectRefDF.col(childTable+"__"+referenceMappingData.childTablePrimaryKey) === pushTableForRejectModelDF.col(pushTable+"__"+referenceMappingData.childTablePrimaryKey),
                                                        "left_outer")
                                                   .drop(childTable+"__"+referenceMappingData.childTablePrimaryKey)
                                                   .drop(pushTable+"__"+referenceMappingData.childTablePrimaryKey)
        
        println("showing childAndPushTableDataForRejectRefDF : ")
        childAndPushTableDataForRejectRefDF.show()
        var s3SourceDFForRejectModelDF = s3SourceDF.join(childAndPushTableDataForRejectRefDF,
                                    s3SourceDF.col(referenceMappingData.sourceRefKey) === childAndPushTableDataForRejectRefDF.col(childTable+"__"+referenceMappingData.childTableRefKey),
                                    "left_outer"
                                    )
        s3SourceDFForRejectModelDF = s3SourceDFForRejectModelDF.filter(row=>{
          val userIdInTable : String = row.getString(row.fieldIndex(pushTable+"__"+referenceMappingData.pushTableRefKey))
          val userIdInSource : String = row.getString(row.fieldIndex(primaySourceKeyQN))
          //val email:String = row.getString(row.fieldIndex(referenceMappingData.sourceRefKey))
          //println(s"email=$email userIdInTable=$userIdInTable userIdInSource=$userIdInSource")
          if(userIdInTable != userIdInSource){
            true
          }else{
            false
          }
        })
        println("showing s3SourceDFForRejectModelDF : ")
        s3SourceDFForRejectModelDF.show()
        s3SourceDFForRejectModelDF = s3SourceDFForRejectModelDF.drop(childTable+"__"+referenceMappingData.childTableRefKey)
                                                               .drop(pushTable+"__"+referenceMappingData.pushTableRefKey)
        
        rejectDF = rejectDF.union(s3SourceDFForRejectModelDF).dropDuplicates()
        sourceRejectDF = sourceRejectDF.union(rejectDF)
        println("showing rejectDF : ")
        rejectDF.show()
        SparkUtils.uploadRejectRecordsToS3(rejectDF, targetName, mappingData.primarySource, s3SourceFileName)
        
        s3SourceDF = s3SourceDF.except(rejectDF)
        sourceDF = sourceDF.union(s3SourceDF)
      }
      //sourceDF = sourceDF.checkpoint(false)
      //sourceRejectDF = sourceRejectDF.checkpoint(false)
      println("Displaying combined sourceDF with all sameName Prefixes from S3 : ")
      sourceDF.show()
      println("Displaying combined sourceRejectDF with all sameName Prefixes from S3 : ")
      sourceRejectDF.show()
      
      sourceDF = SparkUtils.addSourceNameColumnToDF(spark, sourceDF, sourceSystemName, mappingData)
      sourceDF = EntityHandler.combineMultipleSources(spark, sourceDF, targetName, mappingData, sourceRejectDF)
      sourceDF = SparkUtils.combineTableSources(spark, sourceDF, mappingData)
      
      var toBeInsertedSourceDF = sourceDF.join(childTableRefKeyDF, sourceDF.col(referenceMappingData.sourceRefKey) === childTableRefKeyDF.col(referenceMappingData.childTableRefKey), "left_anti")
      //println("toBeInsertedSourceDF")
      //toBeInsertedSourceDF.show()
      val insertCount: Long = toBeInsertedSourceDF.count()
      val tableSchema: String = mappingData.tableSchema
      val seqName: String = referenceMappingData.dbSeqName
      val tempTableQuery: String = "(select nextval('"+tableSchema+".\""+seqName+"\"') as \"id\" from generate_series(1," + insertCount + ")) as \"temp\""
      println("Fetching sequences from database using query \n: "+tempTableQuery)
      var seqDF = spark.read.jdbc(PropertyUtils.getProperty("jdbcURL"), tempTableQuery, JdbcAppUtils.getConnectionProperties)
      val seqArr: Array[Row] = seqDF.collect()

      import spark.implicits._

      val holdSeq = seqArr.map(a => HoldSeq(a.getLong(a.fieldIndex("id")))).toSeq
      seqDF = holdSeq.toDF()
      seqDF = seqDF.withColumn("seq", row_number().over(Window.orderBy("id")))
      //seqDF.show()

      

      toBeInsertedSourceDF = toBeInsertedSourceDF.withColumn("seq", row_number().over(Window.orderBy(primaySourceKeyQN)))
      toBeInsertedSourceDF = toBeInsertedSourceDF.join(seqDF, Seq("seq"), "inner")
      toBeInsertedSourceDF.show()
      var toBeInsertedSourceDFCP = toBeInsertedSourceDF.checkpoint(false)
      
      // changes for SourceSystemXRef starts
      toBeInsertedSourceDFCP = SparkUtils.combineTableSources(spark, toBeInsertedSourceDFCP, pushTableMappingData)
      //toBeInsertedSourceDFCP.show()
      //changes for SourceSystemXRef ends
      
      val toBeInsertedTargetDF = SparkUtils.getTargetDF(toBeInsertedSourceDFCP, mappingData)
      val toBeInsertedChildTargetDF = SparkUtils.getTargetDF(toBeInsertedSourceDFCP, childMappingData)
      val toBePushedTargetDF = SparkUtils.getTargetDF(toBeInsertedSourceDFCP, pushTableMappingData)
      
      //println("toBePushedTargetDF >>>>>>>>>>>>>")
      //toBePushedTargetDF.show()
      
      if (operation == "upsert" || operation == "update") {

        var sourceDFForUpdate = sourceDF.join(childTableDF.select(referenceMappingData.childTableRefKey, childMappingData.primaryKey), sourceDF.col(referenceMappingData.sourceRefKey) === childTableRefKeyDF.col(referenceMappingData.childTableRefKey), "inner")
        sourceDFForUpdate = sourceDFForUpdate.withColumnRenamed(childMappingData.primaryKey, "id")
        //sourceDF.show()

        val targetDF = SparkUtils.getTargetDF(sourceDFForUpdate, mappingData)
        //targetDF.show()
        val tableDF = SparkUtils.getJdbcTableDF(spark, mappingData)
        //tableDF.show()
        //println("toBeUpdatedDF")
        val toBeUpdatedDFWithMaxParts = targetDF.except(tableDF)
        val toBeUpdatedDF: Dataset[Row] = SparkUtils.repartitionData(toBeUpdatedDFWithMaxParts, mappingData)

        //toBeUpdatedDF.show()
        val updatedParentRecordCount: Long = JdbcAppUtils.updateDFToJdbcTarget(toBeUpdatedDF, tableDF, mappingData)
        println(s"$updatedParentRecordCount records updated into target : " + targetName)

        val targetChildDF = SparkUtils.getTargetDF(sourceDFForUpdate, childMappingData)
        //targetChildDF.show()
        //childTableDF.show()
        //println("toBeUpdatedChildDF")
        val toBeUpdatedChildDFWithMaxParts = targetChildDF.except(childTableDF)
        val toBeUpdatedChildDF: Dataset[Row] = SparkUtils.repartitionData(toBeUpdatedChildDFWithMaxParts, childMappingData)
        //toBeUpdatedChildDF.show()
        val updatedChildRecordCount: Long = JdbcAppUtils.updateDFToJdbcTarget(toBeUpdatedChildDF, targetChildDF, childMappingData)
        println(s"$updatedChildRecordCount records updated into target : " + childName)

      }

      val parentRecords: Long = SparkUtils.insertDFToJdbcTarget(toBeInsertedTargetDF, mappingData)
      println(s"$parentRecords records inserted into target : " + targetName)

      val childRecords: Long = SparkUtils.insertDFToJdbcTarget(toBeInsertedChildTargetDF, childMappingData)
      println(s"$childRecords records inserted into target : " + childName)

      
      //changes for SourceSystemXRef starts
      //println("toBePushedTargetDF")
      //toBePushedTargetDF.show()
      val pushTableRecords: Long = SparkUtils.insertDFToJdbcTarget(
        SparkUtils.repartitionData(toBePushedTargetDF, pushTableMappingData),
        pushTableMappingData)
      println(s"$pushTableRecords records inserted into target : " + pushTableName)
      //changes for SourceSystemXRef ends
      // uncaching dfs stored in memory
      childTableDF.unpersist()
      pushTableDF.unpersist()
    }
  }
  
  def combineMultipleSources(spark: SparkSession, sourceDF: Dataset[Row], targetName: String, mappingData: MappingData, sourceRejectDF:Dataset[Row]): Dataset[Row] = {
    var baseSourceDF: Dataset[Row] = sourceDF
    println("combineMultipleSources : No of sources "+mappingData.sourceList.length)
    if (mappingData.sourceList.length > 1) {
      val parts: Array[String] = targetName.split("_")
      val sourceNamePrefix: String = parts(0) + "_" + parts(1) + "_"
      val sourceList: Array[String] = mappingData.sourceList
      val primarySource: String = mappingData.primarySource
      val primarySourceKey: String = mappingData.primarySourceKey
      sourceList.filter(source => source != primarySource).foreach(source => {
         val s3SourcesList: List[String] = S3Util.getS3MatchingFileKeys(
                                                    PropertyUtils.getProperty("sourceDataBucketName"),
                                                    PropertyUtils.getProperty("sourceDataFolderKey") + "/" + source,
                                                    ".dat"
                                                 )
          s3SourcesList.foreach(println)                                       
          var nextS3CombinedSourceDF = SparkUtils.createEmptyDataframe(spark, targetName, source)
          for (s3SourceFileNameKey <- s3SourcesList) {
            val s3SourceFileName: String = s3SourceFileNameKey.replaceFirst(PropertyUtils.getProperty("sourceDataFolderKey") + "/", "")
            println("Processing source file : " + s3SourceFileName)
            var s3SourceDF = SparkUtils.getSourceDF(spark, targetName, source, s3SourceFileName)
            println("Displaying sourceDF from S3 for source: "+source)
            s3SourceDF.show()
            // pick rejectDFs and check for any matching records
            SparkUtils.checkAndProcessPreviousRejectedRecords(spark, targetName, source, s3SourceDF)
            var rejectDF = SparkUtils.getDataTypeMismatchRecords(s3SourceDF, mappingData)
            // handling for email id reference value case starts
            val s3SourceRejectDF = s3SourceDF.join(sourceRejectDF, sourceRejectDF.col(mappingData.primarySource+"__"+primarySourceKey) === s3SourceDF.col(source+"__"+primarySourceKey), "left_semi")
            println("s3SourceRejectDF : ")
            s3SourceRejectDF.show()
            rejectDF = rejectDF.union(s3SourceRejectDF)
            println("rejectDF : ")
            rejectDF.show()
            // handling for email id reference value case ends
            SparkUtils.uploadRejectRecordsToS3(rejectDF, targetName, source, s3SourceFileName)
            //rejectDF.show()
            s3SourceDF = s3SourceDF.except(rejectDF)
            nextS3CombinedSourceDF = nextS3CombinedSourceDF.union(s3SourceDF)
            //sourceDF.show()
          }
        nextS3CombinedSourceDF = nextS3CombinedSourceDF.checkpoint(false) 
        val nextSourceRefKey: String = source + "__" + primarySourceKey
        val sourceRefKey: String = primarySource + "__" + primarySourceKey
        baseSourceDF = baseSourceDF.join(nextS3CombinedSourceDF, baseSourceDF.col(sourceRefKey) === nextS3CombinedSourceDF.col(nextSourceRefKey), "left_outer")
        //println(s"After joining with source $source")
        //sourceDF.show()
      })
    }
    sourceDF
  }

}