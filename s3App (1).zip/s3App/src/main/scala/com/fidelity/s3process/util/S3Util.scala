package com.fidelity.s3process.util

import java.io.BufferedReader
import java.io.File
import java.io.FileWriter
import java.io.InputStreamReader

import org.apache.log4j.Logger

import com.fidelity.s3process.config.S3Config
import com.amazonaws.services.s3.model.PutObjectResult
import com.amazonaws.services.s3.model.ObjectListing
import com.amazonaws.services.s3.model.S3ObjectSummary
import com.amazonaws.services.s3.model.DeleteObjectRequest

object S3Util {
  
  
	val log:Logger = Logger.getLogger(S3Util.getClass);
  
  def uploadFile(bucketName:String,s3key:String,localFilePath:String):Boolean={
    var isUploaded = false
    try{
      val s3Client = S3Config.getS3Client
      s3Client.putObject(bucketName, s3key, new File(localFilePath))
      isUploaded = true
    }catch{
      case e: Exception => isUploaded = false
    }
    isUploaded
  }
  
  def uploadFolder(bucketName:String,s3key:String,localFilePath:String):Unit={
    var isUploaded = false
    try{
      val s3Client = S3Config.getS3Client
      s3Client.putObject(bucketName, s3key, new File(localFilePath))
      isUploaded = true
    }catch{
      case e: Exception => isUploaded = false
    }
    isUploaded
  }
  
  def download(bucketName:String,s3key:String,localFilePath:String):String={
    try{
     val s3Client = S3Config.getS3Client
     val s3Object = s3Client.getObject(bucketName, s3key)
     FileUtils.createFileIfNotExists(localFilePath)
     val writer:FileWriter = new FileWriter(localFilePath)
     val reader:BufferedReader =new BufferedReader(new InputStreamReader(s3Object.getObjectContent))
     var line:String = reader.readLine()
     while(line!=null){
       writer.write(line)
       writer.write(System.lineSeparator())
       line= reader.readLine()
     }
     reader.close()
     writer.close()
    }catch  {
		  case e: Exception  =>{
		                        log.error(s"Error occured while downloading : bucketName=$bucketName, s3key=$s3key, localFilePath=$localFilePath")
		                        throw e
		                        }
		}
     localFilePath
  }
  
   def deleteObject(bucketName:String,s3key:String):Boolean={
    var isDeleted = false
    try{
     val s3Client = S3Config.getS3Client
     s3Client.deleteObject(new DeleteObjectRequest(bucketName, s3key))
     isDeleted = true
    }
    catch{
      case e:Exception => {
		                        log.error(s"Error occured while deleting : bucketName=$bucketName, s3key=$s3key")
		                        throw e
		                      }
    }
    isDeleted
  }
   
  def getListOfLines(bucketName:String,s3key:String):List[String]={
     val s3Client = S3Config.getS3Client
     val s3Object = s3Client.getObject(bucketName, s3key)
     val reader:BufferedReader =new BufferedReader(new InputStreamReader(s3Object.getObjectContent))
     var list:List[String] = Nil
     var line:String = reader.readLine()
     while(line!=null){
       list = line::list
       line= reader.readLine()
     }
     reader.close()
     list
   }
  
  def getJsonString(bucketName:String,s3key:String):String={
     val s3Client = S3Config.getS3Client
     val s3Object = s3Client.getObject(bucketName, s3key)
     val reader:BufferedReader =new BufferedReader(new InputStreamReader(s3Object.getObjectContent))
     var jsonString:StringBuilder = new StringBuilder()
     var line:String = reader.readLine()
     while(line!=null){
       jsonString.append(line)
       line= reader.readLine()
     }
     reader.close()
     jsonString.toString()
   }
  
  import scala.collection.JavaConverters.asScalaBufferConverter
  def getS3MatchingFileKeys(bucketName:String,s3keyPrefix:String, s3keySuffix:String):List[String]={
    val s3Client = S3Config.getS3Client
    val s3ObjectSummaries:java.util.List[S3ObjectSummary] = s3Client.listObjects(bucketName).getObjectSummaries
    val s3ObjectSummariesList:List[S3ObjectSummary] = s3ObjectSummaries.asScala.toList
    s3ObjectSummariesList.filter(a=>{
    		val key : String = a.getKey
        val startsWith: String  = s3keyPrefix
    		val endsWith: String  = "\\"+s3keySuffix
    		val pattern : String = startsWith+"[\\d]{8}-[\\d]{1,6}"+endsWith
    		println("looking for s3 keys matching te pattern : "+pattern)
		    key.matches(pattern)
    }).map(a=>a.getKey).toList
  }
  
  
		
  def getS3FileKey(bucketName:String, keyPrefix:String):String={""}
  
}