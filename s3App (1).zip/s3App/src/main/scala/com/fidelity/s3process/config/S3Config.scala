package com.fidelity.s3process.config

import org.apache.log4j.Logger

import com.amazonaws.auth.AWSStaticCredentialsProvider
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.services.s3.AmazonS3
import com.amazonaws.services.s3.AmazonS3ClientBuilder
import com.fidelity.s3process.util.PropertyUtils
import com.amazonaws.services.s3.transfer.TransferManager
import com.amazonaws.services.s3.transfer.TransferManagerBuilder

object S3Config{

	val log:Logger = Logger.getLogger(S3Config.getClass);
	
	val region:String = PropertyUtils.getProperty("region")
	val accessKeyId:String = PropertyUtils.getProperty("accessKeyId")
	val secretAccessKey:String = PropertyUtils.getProperty("secretAccessKey")
	def initS3client():AmazonS3={
		
		log.info("Getting Amazon S3 client Object ")
        
		val awsCreds:BasicAWSCredentials = new BasicAWSCredentials(accessKeyId, secretAccessKey)
		val s3Client:AmazonS3 = AmazonS3ClientBuilder.standard()
									                               .withRegion(region)
			                                           .withCredentials(new AWSStaticCredentialsProvider(awsCreds))
			                                           .build()
		log.info("Got the Amazon S3 client object successfully!")	                                           
    s3Client
  }
	
	private var s3Client:AmazonS3 = null
	
	def getS3Client:AmazonS3={
	  if(s3Client==null) s3Client= initS3client()
	  s3Client
	}
	
	private var s3TransferManager:TransferManager = null
	
	def getS3TransferManager:TransferManager={
	  
	  if(s3TransferManager == null){
	    s3TransferManager = TransferManagerBuilder.standard().withS3Client(getS3Client).build()
	  }
		s3TransferManager
	}
	
}