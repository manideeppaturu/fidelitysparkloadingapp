package com.fidelity.s3process

import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import org.apache.log4j.Logger
import org.apache.log4j.Level

import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.SparkSession

import com.fidelity.s3process.extras.EntityHandler
import com.fidelity.s3process.extras.UDFManager
import com.fidelity.s3process.util.JdbcAppUtils
import com.fidelity.s3process.util.JsonUtils
import com.fidelity.s3process.util.JsonUtils.MappingData
import com.fidelity.s3process.util.LoggerUtils
import com.fidelity.s3process.util.PropertyUtils
import com.fidelity.s3process.util.S3Util
import com.fidelity.s3process.util.SparkUtils
import com.fidelity.s3process.util.FileUtils
import com.fidelity.s3process.beans.DAPJobStatus
import com.fidelity.s3process.util.DateTimeUtil
import com.fidelity.s3process.util.NamesUtil

object App {

  val log: Logger = Logger.getLogger(App.getClass)

  def main(args: Array[String]) {
    val startTime = System.currentTimeMillis()
    val startTimestamp: String = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
    println("started at : " + startTimestamp)
    System.setProperty("hadoop.home.dir", "D:\\Jagadeesh\\hadoop\\winutils-master\\hadoop-2.8.3")
    // Loading properties from application.properties
    //PropertyUtils.initProperties("local.application.properties")
    PropertyUtils.initProperties("application.properties")
    // Configuring for Log4j
    LoggerUtils.configure(PropertyUtils.getProperty("log4jConfigPath"))
    //process config file from S3
    //Getting spark session
    val spark = SparkSession.builder.appName("s3app").master("local[*]").getOrCreate()

    spark.sparkContext.setLogLevel("ERROR")

    spark.conf.set("spark.sql.crossJoin.enabled", "true")
    spark.sparkContext.setCheckpointDir(PropertyUtils.getProperty("checkPointDir"))

    //registering all custom udfs to be used in sql(transform mapping files) for our application code
    UDFManager.registerUDFs(spark)

    val jsonString: String = FileUtils.getJsonString(PropertyUtils.getProperty("configFile"))
    //val jsonString:String = S3Util.getJsonString(PropertyUtils.getProperty("configFileBucketName"), PropertyUtils.getProperty("configFileKey"))
    val targetList: Array[String] = JsonUtils.getTargetList(jsonString)

    println("Target List : ")
    targetList.foreach(println)

    for (target <- targetList) {
      val dAPJobStatus: DAPJobStatus = new DAPJobStatus()
      dAPJobStatus.jobStatus = "SUCCESS"
      val targetName: String = target.trim()
      println("Started processing : " + targetName)

      val mappingData: MappingData = SparkUtils.getMappingData(targetName)
      val sourceNamePrefix: String = NamesUtil.getSourceNamePrefix(targetName)
      val sourceSystemName: String = NamesUtil.getSourceSystemName(targetName)
      val primarySourceName: String = sourceNamePrefix + mappingData.primarySource
      dAPJobStatus.sourceType = NamesUtil.getSourceType(targetName)
      dAPJobStatus.sourceItem = mappingData.primarySource
      dAPJobStatus.jobType = "InBound"
      dAPJobStatus.lastRunTimestamp = startTimestamp
      
      var operation: String = if (mappingData.operation == null) "" else mappingData.operation
      operation = if (operation == "delta") "insert" else "upsert"
      println(s"************operation=$operation************")
      
     try {
        // For entities like Individual (special case handling)
        if (EntityHandler.isSpecialCase(mappingData)) {
          EntityHandler.handleEntity(spark, targetName, mappingData, operation)
        } 
        else 
        {  
          var sourceDF = SparkUtils.createEmptyDataframe(spark, targetName, mappingData.primarySource)
          val sourceList: Array[String] = mappingData.sourceList
          val s3SourcesList: List[String] = S3Util.getS3MatchingFileKeys(
                                                                          PropertyUtils.getProperty("sourceDataBucketName"),
                                                                          PropertyUtils.getProperty("sourceDataFolderKey") + "/" + primarySourceName,
                                                                          ".dat"
                                                                         )

          for (s3SourceFileNameKey <- s3SourcesList) {
            val s3SourceFileName: String = s3SourceFileNameKey.replaceFirst(PropertyUtils.getProperty("sourceDataFolderKey") + "/", "")
            println("Processing source file : " + s3SourceFileName)
            var s3SourceDF = SparkUtils.getSourceDF(spark, targetName, mappingData.primarySource, s3SourceFileName)
            println("Displaying sourceDF from S3 : ")
            s3SourceDF.show()
            // pick rejectDFs and check for any matching records
            SparkUtils.checkAndProcessPreviousRejectedRecords(spark, targetName, mappingData.primarySource, s3SourceDF)
    
            val rejectDF = SparkUtils.getDataTypeMismatchRecords(s3SourceDF, mappingData)
            SparkUtils.uploadRejectRecordsToS3(rejectDF, targetName, mappingData.primarySource, s3SourceFileName)
    
            //rejectDF.show()
            s3SourceDF = s3SourceDF.except(rejectDF)
            sourceDF = sourceDF.union(s3SourceDF)
          }
          println("Displaying combined sourceDF with all sameName Prefixes from S3 : ")
          sourceDF.show()

          sourceDF = SparkUtils.addSourceNameColumnToDF(spark, sourceDF, sourceSystemName, mappingData)
          sourceDF = SparkUtils.combineMultipleSources(spark, sourceDF, targetName, mappingData)
          sourceDF = SparkUtils.combineTableSources(spark, sourceDF, mappingData)
          val tableDF = SparkUtils.getJdbcTableDF(spark, mappingData)
          println("tableDF")
          tableDF.show()
          val targetDF = SparkUtils.getTargetDF(sourceDF, mappingData)
          //println("targetDF")
          //targetDF.show()
          val partitionCount: Int = PropertyUtils.getProperty("partitionCount").toInt
          val toBeInsertedDFWithMaxParts = targetDF.join(tableDF, Seq(mappingData.primaryKey), "left_anti")
          val toBeInsertedDF = SparkUtils.repartitionData(toBeInsertedDFWithMaxParts, mappingData)

          if (operation == "upsert" || operation == "update") {
            // spark.sql.shuffle.partitions (default: 200), cannot afford 200 DB connections so reduce by 20 (can change the code to tune in future)
            val toBeUpdatedDFWithMaxParts = targetDF.except(tableDF).except(toBeInsertedDF)
            val toBeUpdatedDF = SparkUtils.repartitionData(toBeUpdatedDFWithMaxParts, mappingData)
            //println("toBeUpdatedDF into Database")
            //toBeUpdatedDF.printSchema()
            //toBeUpdatedDF.show()
            val updatedRecordCount: Long = JdbcAppUtils.updateDFToJdbcTarget(toBeUpdatedDF, tableDF, mappingData)
            println(s"$updatedRecordCount records updated into target : " + targetName)
          }
          //println("toBeInsertedDF into Database")
          //toBeInsertedDF.printSchema()
          //toBeInsertedDF.show()
          val insertedRecordCount: Long = SparkUtils.insertDFToJdbcTarget(toBeInsertedDF, mappingData)
          println(s"$insertedRecordCount records inserted into target : " + targetName)
        }

      } catch {
        case e: Exception => {
          e.printStackTrace()
          dAPJobStatus.jobStatus = "FAILURE"
          if (log.isEnabledFor(Level.ERROR)) {
            log.error(s"Error occured during job run for target : $targetName", e)
          }
        }
      } finally {
        JdbcAppUtils.captureDAPJobStatus(sourceSystemName, dAPJobStatus)
      }
    }
    spark.stop();
    val totalTimeConsumedInSecs = (System.currentTimeMillis() - startTime) / 1000
    println(s"Total Time consumed :  $totalTimeConsumedInSecs seconds")
    print("Ended at : " + LocalDateTime.now())
  }
}