package com.fidelity.s3process.util

import java.time.format.DateTimeFormatter
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit

object DateTimeUtil {
  
 /* def main(args: Array[String]): Unit = {
    println(getAgeInDays("bSolo_DB_product_20190110-041522.dat"))
  }
  */
  
  def getAgeInDays(fileName:String):Long={
    val fileTimestamp:String=getFileTimestampString(fileName)
    //bSolo_DB_product_20191115-041522.dat
    val formatter:DateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")
    val fileDateTime:LocalDateTime = LocalDateTime.parse(fileTimestamp, formatter)
    val currentDateTime:LocalDateTime = LocalDateTime.parse(LocalDateTime.now().format(formatter), formatter)
    val days:Long = ChronoUnit.DAYS.between(fileDateTime,currentDateTime)
    println("Age of file in days : " + days)
    days
  }
  
  def getFileTimestampString(fileName:String):String={
    // extension = ".dat" or ".reject" eg : bSolo_DB_product_20191115-041522.dat or bSolo_DB_product_20191115-041522.reject
    val extensionStartsAt = fileName.lastIndexOf(".") 
    val extensionEndsAt = fileName.length() 
    val extension :String = fileName.substring(extensionStartsAt, extensionEndsAt)
    val beginIndex: Int = fileName.lastIndexOf(".") - 15 // bSolo_DB_product_20191115-041522.dat
    val endIndex: Int = fileName.lastIndexOf(extension)
    val fileTimestamp: String = fileName.substring(beginIndex, endIndex)
    fileTimestamp
  }
}