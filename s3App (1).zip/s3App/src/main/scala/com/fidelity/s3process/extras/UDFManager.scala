package com.fidelity.s3process.extras

import org.apache.spark.sql.SparkSession

object UDFManager {
  
  def registerUDFs(spark:SparkSession):Unit={
    spark.udf.register("fingerprint", generateFingerprint(_:String, _:String))        
  }
  
  def generateFingerprint(a:String, b:String):String={
    a+"_"+b
  }
  
}