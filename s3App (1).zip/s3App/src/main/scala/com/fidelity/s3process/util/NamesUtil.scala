package com.fidelity.s3process.util

object NamesUtil {
  
    def getSourceSystemName(targetName:String):String={
      val parts: Array[String] = targetName.split("_")
      val sourceNamePrefix: String = parts(0) + "_" + parts(1) + "_"
      val sourceSystemName: String = parts(0) + "_" + parts(1) 
      sourceSystemName
    }
    
    def getSourceNamePrefix(targetName:String):String={
      val parts: Array[String] = targetName.split("_")
      val sourceNamePrefix: String = parts(0) + "_" + parts(1) + "_"
      sourceNamePrefix
    }
    
    def getSourceType(targetName:String):String={
      val parts: Array[String] = targetName.split("_")
      val sourceType: String = parts(1)
      sourceType
    }
    
}