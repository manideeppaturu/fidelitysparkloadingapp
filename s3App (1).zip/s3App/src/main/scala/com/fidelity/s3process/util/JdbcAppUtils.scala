package com.fidelity.s3process.util

import java.util.Properties
import java.sql.SQLException
import java.sql.PreparedStatement
import java.sql.Connection
import java.sql.DriverManager


import org.apache.spark.sql.Dataset
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.types.StructField
import org.apache.log4j.Logger

import com.fidelity.s3process.util.JsonUtils.MappingData
import com.fidelity.s3process.util.JsonUtils.SourceTableObject
import org.apache.spark.sql.SparkSession
import java.time.LocalDateTime
import com.fidelity.s3process.beans.DAPJobStatus
import java.sql.Statement
import java.sql.ResultSet
import java.time.format.DateTimeFormatter


object JdbcAppUtils {
  
 val log:Logger = Logger.getLogger(JdbcAppUtils.getClass);
 
 def main(args: Array[String]): Unit = {
    /*val startTime = System.currentTimeMillis()
    println("started at : " + LocalDateTime.now())
    System.setProperty("hadoop.home.dir", "D:\\Jagadeesh\\hadoop\\winutils-master\\hadoop-2.8.3")
    // Loading properties from application.properties
    PropertyUtils.initProperties("local.application.properties")
    //PropertyUtils.initProperties("application.properties")
    // Configuring for Log4j
    LoggerUtils.configure(PropertyUtils.getProperty("log4jConfigPath"))
    //process config file from S3
    //Getting spark session
    val spark = SparkSession.builder.appName("s3app").master("local[*]").getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

   val mappingData : MappingData = SparkUtils.getMappingData("bSolo_DB_ProductIndividualRelationship")
   val sourceTableList:Array[SourceTableObject] = mappingData.sourceTableList
	  if(sourceTableList!=null && sourceTableList.length>0){
        for (sourceTableobject <- sourceTableList) {
          val sourceTableName:String = sourceTableobject.tableName
          val customTableQuery:String = JdbcAppUtils.createCustomTableQuery(mappingData.tableSchema, sourceTableobject)
          println(s"customTableQuery : $customTableQuery")
          val sourceTableDF = SparkUtils.getJdbcTableDF(spark, customTableQuery)
          sourceTableDF.show()
        }
     }
    spark.close()*/
   PropertyUtils.initProperties("application.properties")
   val timestamp: String = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
   val dAPJobStatus : DAPJobStatus = new DAPJobStatus
   dAPJobStatus.lastRunTimestamp = timestamp
   dAPJobStatus.jobType = "InBound"
   dAPJobStatus.sourceItem = "bikes"
   dAPJobStatus.sourceType = "DB"
   dAPJobStatus.jobStatus = "SUCCESS"
   captureDAPJobStatus("bSolo_DB", dAPJobStatus)
 }
  
  def createUpdateQuery(tableName:String , columns:Array[String], primaryKey:String):String={
    
    val updateColumns: Array[String] = columns.filterNot(column=>column==primaryKey).map(column=>"\""+column+"\""+"=?").toArray
    val columnsStr:String = updateColumns.mkString(",")
    val updateQuery:String = "UPDATE "+tableName+" SET "+columnsStr+" WHERE \""+primaryKey+"\"=?"
    updateQuery              
  }
  
  def createCustomTableQuery(tableSchema:String, sourceTableObject:SourceTableObject):String={
    val tableName:String = sourceTableObject.tableName
    val loadColumns:Array[String] = sourceTableObject.loadColumns
    val columns : String = loadColumns.map(column=> "\""+column+"\" as \""+tableName+"__"+column+"\" ").mkString(",")
    val customTableQuery:String = "(select "+columns+" from "+tableSchema+".\""+tableName+"\") as \""+tableName+"\""
    customTableQuery
  }
  
  private var connectionProperties:Properties = null
  
  def getConnectionProperties():Properties={
    if(connectionProperties==null){
      connectionProperties = new Properties()
      connectionProperties.setProperty("user", PropertyUtils.getProperty("jdbcUserName"))
      connectionProperties.setProperty("password", PropertyUtils.getProperty("jdbcPassword"))
      connectionProperties.setProperty("driver", PropertyUtils.getProperty("jdbcDriver"))
    }
    connectionProperties
  }
  
  def updateDFToJdbcTarget(toBeUpdatedDF: Dataset[Row], tableDF: Dataset[Row], mappingData: MappingData): Long = {

    println(s"Updating data to the DB table")
    val tableSchema: String = mappingData.tableSchema
    val tableName: String = mappingData.tableName
    val primaryKey: String = mappingData.primaryKey
    val jdbcSchema: String = "\"" + tableSchema + "\""
    val jdbcTableName: String = "\"" + tableName + "\""
    val qualifiedJdbcTableName: String = s"$jdbcSchema.$jdbcTableName"
    println(s"jdbcSchema=$jdbcSchema")
    println(s"jdbcTableName=$jdbcTableName")
    println(s"qualifiedJdbcTableName=$qualifiedJdbcTableName")
    val jdbcQuery: String = JdbcAppUtils.createUpdateQuery(qualifiedJdbcTableName, tableDF.columns, primaryKey)
    println(s"JDBC Query Formation : $jdbcQuery")

    val toBeUpdatedRecordCount: Long = toBeUpdatedDF.count()

    if (toBeUpdatedRecordCount > 0) {
      val remFields = tableDF.schema.fields.filterNot(field => field.name == primaryKey).toArray
      val primaryKeyField = tableDF.schema.fields.filter(field => field.name == primaryKey).toArray
      toBeUpdatedDF.foreachPartition(rows => {
        // jdbc code here
        //Class.forName(PropertyUtils.getProperty("jdbcDriver"))
        val conn: Connection = DriverManager.getConnection(PropertyUtils.getProperty("jdbcURL"), JdbcAppUtils.getConnectionProperties)
        val isAutoCommitEnabled: Boolean = conn.getAutoCommit()
        val pstmt: PreparedStatement = conn.prepareStatement(jdbcQuery)
        try {
          rows.foreach(row => {
            Array.tabulate(remFields.length) { i => (remFields(i), i + 1) }.foreach(t => {
              val field: StructField = t._1
              val index: Int = t._2
              field.dataType match {
                case DataTypes.IntegerType => pstmt.setInt(index, row.getInt(row.fieldIndex(field.name)))
                case DataTypes.LongType => pstmt.setLong(index, row.getLong(row.fieldIndex(field.name)))
                case DataTypes.FloatType => pstmt.setFloat(index, row.getFloat(row.fieldIndex(field.name)))
                case DataTypes.DoubleType => pstmt.setDouble(index, row.getDouble(row.fieldIndex(field.name)))
                case DataTypes.StringType => pstmt.setString(index, row.getString(row.fieldIndex(field.name)))
                case _ => pstmt.setString(index, row.getString(row.fieldIndex(field.name)))
              }
            })
            val refField: StructField = primaryKeyField(0)
            val index: Int = remFields.size + 1
            refField.dataType match {
              case DataTypes.IntegerType => pstmt.setInt(index, row.getInt(row.fieldIndex(refField.name)))
              case DataTypes.LongType => pstmt.setLong(index, row.getLong(row.fieldIndex(refField.name)))
              case DataTypes.FloatType => pstmt.setFloat(index, row.getFloat(row.fieldIndex(refField.name)))
              case DataTypes.DoubleType => pstmt.setDouble(index, row.getDouble(row.fieldIndex(refField.name)))
              case DataTypes.StringType => pstmt.setString(index, row.getString(row.fieldIndex(refField.name)))
              case _ => pstmt.setString(index, row.getString(row.fieldIndex(refField.name)))
            }
            pstmt.addBatch()
          })
          pstmt.executeBatch()
          if (!isAutoCommitEnabled) conn.commit()
        } catch {
          case e: SQLException => log.error("Error occcured during JDBC batch update : ", e)
          case e: Exception => log.error("Error occcured while saving updated data to DB : ", e)
        } finally {
          pstmt.close()
          conn.close()
        }
      })
      println(s"Updated data to the table : $jdbcTableName")
    }
     toBeUpdatedRecordCount
  }
  
  
  def captureDAPJobStatus(sourceName:String, dAPJobStatus:DAPJobStatus):Int={
    var recordsCaptured = 0 
    val conn: Connection = DriverManager.getConnection(PropertyUtils.getProperty("jdbcURL"), JdbcAppUtils.getConnectionProperties)
    val isAutoCommitEnabled: Boolean = conn.getAutoCommit()
    val stmt: Statement = conn.createStatement()
    try{
      val query: String = "select \"SourceSystemID\" from  public.\"SourceSystem\" where \"SourceSystemName\"='"+sourceName+"'" 
      val rs:ResultSet = stmt.executeQuery(query)
      if(rs!=null){
        if(rs.next()){
          dAPJobStatus.sourceSystemID = rs.getInt(1)
        }else{
          println(s"Error: SourceSystemID is not configured for the SourceSystemName=$sourceName")
        }
        rs.close()
      }
    }catch{
      case se: SQLException => log.error("Error occured during DB select query : ", se)
      case e: Exception => log.error("Error occured : ", e)
    }finally {
      stmt.close()
    }
   
    if(Option(dAPJobStatus.sourceSystemID).isDefined){
      var pstmt: PreparedStatement = null
      val query: String = "insert into public.\"DAPJob\" (\"SourceSystemID\", \"SourceType\", \"SourceItem\" , \"JobType\", \"LastRunTimeStamp\", \"JobStatus\" ) values (?,?,?,?,to_timestamp(?, 'yyyy-mm-dd hh24:mi:ss'), ?)"
      try{
        pstmt = conn.prepareStatement(query)
        pstmt.setInt(1, dAPJobStatus.sourceSystemID)
        pstmt.setString(2, dAPJobStatus.sourceType)
        pstmt.setString(3, dAPJobStatus.sourceItem)
        pstmt.setString(4, dAPJobStatus.jobType)
        pstmt.setString(5, dAPJobStatus.lastRunTimestamp)
        pstmt.setString(6, dAPJobStatus.jobStatus)
        recordsCaptured = pstmt.executeUpdate()
        if (!isAutoCommitEnabled) conn.commit()
      }catch{
        case se: SQLException => log.error("Error occured during DB select query : ", se)
        case e: Exception => log.error("Error occured : ", e)
      }finally{
        if(pstmt!=null) pstmt.close()
      }
    }
    if(conn!=null) conn.close()
    recordsCaptured
  }
  
}