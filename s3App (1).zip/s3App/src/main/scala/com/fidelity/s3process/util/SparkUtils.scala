package com.fidelity.s3process.util

import scala.collection.mutable.HashMap

import org.apache.log4j.Logger
import org.apache.spark.sql.Column
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.Row
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.types.DataType
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType

import com.fidelity.s3process.util.JsonUtils.MappingData
import com.fidelity.s3process.util.JsonUtils.ReferenceMappingData
import com.fidelity.s3process.util.JsonUtils.SourceTableObject
import com.fidelity.s3process.util.JsonUtils.TargetColumn
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import com.fidelity.s3process.config.S3Config

object SparkUtils {

  val log: Logger = Logger.getLogger(SparkUtils.getClass);

  def createEmptyDataframe(spark: SparkSession,targetName: String, sourceName: String):Dataset[Row] = {
    val parts: Array[String] = targetName.split("_")
    val sourceNamePrefix: String = parts(0) + "_" + parts(1) + "_"
    val qualifiedSourceName: String = sourceNamePrefix + sourceName
    val sourceSchema: StructType = SparkUtils.buildSourceSchema(qualifiedSourceName)
    val sourceSchemaWithPrefix: StructType = StructType(sourceSchema.fields.map(field => StructField(sourceName + "__" + field.name, field.dataType)).toSeq)
    spark.createDataFrame(spark.sparkContext.emptyRDD[Row], sourceSchemaWithPrefix)
  }
  
  def getSourceDF(spark: SparkSession, targetName: String, sourceName: String, s3SourceFileName: String): Dataset[Row] = {

    val parts: Array[String] = targetName.split("_")
    val sourceNamePrefix: String = parts(0) + "_" + parts(1) + "_"
    val qualifiedSourceName: String = sourceNamePrefix + sourceName
    //downloading source file
    /*
    val sourceFile:String = S3Util.download(
                                              PropertyUtils.getProperty("sourceDataBucketName"),
                                              PropertyUtils.getProperty("sourceDataFolderKey")+"/"+qualifiedSourceName+".dat",
                                              PropertyUtils.getProperty("localSourceFolderPath")+"/"+qualifiedSourceName+".dat"
                                            )
    */
    val sourceFile: String = PropertyUtils.getProperty("localSourceFolderPath") + s"/$s3SourceFileName"
    val sourceSchema: StructType = SparkUtils.buildSourceSchema(qualifiedSourceName)
    val sourceSchemaWithPrefix: StructType = StructType(sourceSchema.fields.map(field => StructField(sourceName + "__" + field.name, field.dataType)).toSeq)
    var sourceDF = spark.read.option("header", "true").option("delimiter", "|").schema(sourceSchemaWithPrefix).csv(sourceFile)
    sourceDF
  }

  def checkAndProcessPreviousRejectedRecords(spark: SparkSession, targetName: String, actualSource: String, sourceDF: Dataset[Row]): Unit = {

    val parts: Array[String] = targetName.split("_")
    val sourceNamePrefix: String = parts(0) + "_" + parts(1) + "_"
    //val primarySource: String = mappingData.primarySource
    val qualifiedSourceName: String = sourceNamePrefix + actualSource
    val sourceSchema: StructType = SparkUtils.buildSourceSchema(qualifiedSourceName)
    val sourceSchemaWithPrefix: StructType = StructType(sourceSchema.fields.map(field => StructField(actualSource + "__" + field.name, field.dataType)).toSeq)
    val joinColumn: String = actualSource + "__" + "user_id"
    //downloading all rejectFiles for a given source
    // NOTE: logic to get all reject files for given source and their s3 keys 
    val rejectS3Keys: List[String] = S3Util.getS3MatchingFileKeys(
                                                                    PropertyUtils.getProperty("rejectDataBucketName"),
                                                                    PropertyUtils.getProperty("rejectDataFolderKey") + "/" + qualifiedSourceName,
                                                                    ".reject"  
                                                                  )
    if (rejectS3Keys != null && rejectS3Keys.size > 0) {
      println(s"Reject key list for : qualifiedSourceName")
      var rejectS3KeysConsolidatedList : List[String] = Nil
      rejectS3Keys.foreach(rejectFileS3Key=>{
        val beginIndex: Int = rejectFileS3Key.lastIndexOf("/") + 1
        val endIndex: Int = rejectFileS3Key.length()
        val rejectFileName: String = rejectFileS3Key.substring(beginIndex, endIndex)
        val ageInDays : Long = DateTimeUtil.getAgeInDays(rejectFileName)
        if(ageInDays>30){
          val isDeleted: Boolean = S3Util.deleteObject(PropertyUtils.getProperty("rejectDataBucketName"), rejectFileS3Key)
          if (isDeleted) {
            println(s"Age > 30 days, removing reject file $rejectFileS3Key from S3")
          }
        }else{
          rejectS3KeysConsolidatedList = List(rejectFileS3Key) ::: rejectS3KeysConsolidatedList
        }
      })
      
      
      val rejectFolderPath: String = PropertyUtils.getProperty("localRejectFolderPath") + "/" + actualSource

      val rejectS3keyMap: java.util.HashMap[String, String] = new java.util.HashMap[String, String]()
      val rejectFileMap: java.util.HashMap[String, String] = new java.util.HashMap[String, String]()

      rejectS3KeysConsolidatedList.foreach(rejectS3Key => {
        val beginIndex: Int = rejectS3Key.lastIndexOf("/") + 1
        val endIndex: Int = rejectS3Key.length()
        val rejectFileName: String = rejectS3Key.substring(beginIndex, endIndex)
        rejectS3keyMap.put(rejectS3Key, rejectFolderPath + "/" + rejectFileName)
        rejectFileMap.put(rejectFolderPath + "/" + rejectFileName, rejectS3Key)
      })
      
      println(rejectS3keyMap)
      println(rejectFileMap)
      
      rejectS3KeysConsolidatedList.foreach(rejectS3Key => {
        S3Util.download(
          PropertyUtils.getProperty("rejectDataBucketName"),
          rejectS3Key,
          rejectS3keyMap.get(rejectS3Key))
      })
      
      val rejectFolder: File = new File(rejectFolderPath)
      rejectFolder.listFiles().filter(file => file.getName.endsWith(".reject")).foreach(file => {
        val rejectFileName: String = file.getAbsolutePath.replace("\\", "/")
        println("processing reject records file : " + rejectFileName)
        val rejectDF = spark.read.option("header", "false").option("delimiter", "|").schema(sourceSchemaWithPrefix).csv(rejectFileName)
        val resultDF = rejectDF.join(sourceDF, rejectDF.col(joinColumn) === sourceDF.col(joinColumn), "left_anti")
        rejectDF.cache()
        resultDF.cache()
        val rejectCount = rejectDF.count()
        val resultCount = resultDF.count()
        //println("sourceDF : ")
        //sourceDF.show()
        //println("rejectDF : ")
        //rejectDF.show()
        //println("resultDF : ")
        //resultDF.show()
        if (resultCount == 0) {
          //logic for delete reject file from S3
          val rejectFileS3Key: String = rejectFileMap.get(rejectFileName)
          println("All reject records found in New Source so Deleting the file in S3 with s3Key : " + rejectFileS3Key)
          val isDeleted: Boolean = S3Util.deleteObject(PropertyUtils.getProperty("rejectDataBucketName"), rejectFileS3Key)
          if (isDeleted) {
            // delete file from local file system
            file.delete()
          }
        } else {
          // saving dataframe to csv
          println("saving result dataframe to reject file")
          val isSaved: Boolean = saveDataFrameToCSV(resultDF, rejectFolderPath, file.getName)
          if (isSaved) {
            // logic to delete old reject file
            val rejectFileS3Key: String = rejectFileMap.get(rejectFileName)
            val isDeleted: Boolean = S3Util.deleteObject(PropertyUtils.getProperty("rejectDataBucketName"), rejectFileS3Key)
            println(s"$rejectFileS3Key : Old Reject file delete from S3 done ? " + isDeleted)
            if (isDeleted) {
              val isUploaded: Boolean = S3Util.uploadFile(PropertyUtils.getProperty("rejectDataBucketName"), rejectFileS3Key, rejectFileName)
              println(s"$rejectFileS3Key : New Reject file upload done ? " + isUploaded)
              if (isUploaded) {
                // remove file from local machine
                file.delete()
              }
            }
          }

        }
        rejectDF.unpersist(true)
        resultDF.unpersist(true)
      })
      FileUtils.deleteDirectory(rejectFolderPath)
    }

  }

  def getMappingData(targetName: String): MappingData = {

    val mappingJsonString: String = FileUtils.getJsonString(PropertyUtils.getProperty("mappingDataFolder") + "/" + targetName + ".map")
    //val mappingJsonString:String = S3Util.getJsonString(PropertyUtils.getProperty("mappingDataBucketName"),
    //                                                    PropertyUtils.getProperty("mappingDataFolderKey")+"/"+name+".map")
    println(s"parsing json at mapping file $targetName.map")
    println(s"********$targetName map JSON starts***********")
    println(mappingJsonString)
    println(s"********$targetName map JSON ends***********")
    val mappingData: MappingData = JsonUtils.getMappingData(mappingJsonString)
    mappingData
  }

  def getReferenceMappingData(targetName: String): ReferenceMappingData = {
    val refMappingJsonString: String = FileUtils.getJsonString(PropertyUtils.getProperty("mappingDataFolder") + "/" + targetName + "_Reference.map")
    //val refMappingJsonString:String = S3Util.getJsonString(PropertyUtils.getProperty("mappingDataBucketName"),
    //                                                    PropertyUtils.getProperty("mappingDataFolderKey")+"/"+name+".map""_Reference.map")
    val referenceMappingData: ReferenceMappingData = JsonUtils.getReferenceMappingData(refMappingJsonString)
    referenceMappingData
  }

  def buildSourceSchema(metaDataFileName: String): StructType = {

    val metadataJsonString: String = FileUtils.getJsonString(PropertyUtils.getProperty("metadataFolder") + "/" + metaDataFileName + ".md")
    //val metadataJsonString:String = S3Util.getJsonString(PropertyUtils.getProperty("metaDataBucketName"), 
    //                                                    PropertyUtils.getProperty("metaDataFolderKey")+"/"+metaDataFileName+".md")
    val sourceIndexMap: HashMap[Int, String] = JsonUtils.getMetaDataMap(metadataJsonString)
    val orderedIndexList: List[Int] = sourceIndexMap.keys.toList.sortWith((a, b) => a < b)
    val sourceFieldsSeq: Seq[StructField] = orderedIndexList.map(pos => StructField(sourceIndexMap(pos), StringType)).toSeq
    val sourceSchema: StructType = StructType(sourceFieldsSeq)
    sourceSchema
  }

  def buildTargetSchema(mappingData: MappingData): StructType = {
    //Building Target Schema
    val targetColumns: Array[TargetColumn] = mappingData.targetColumns
    val targetFieldsSeq: Seq[StructField] = targetColumns.map(column => StructField(column.name, getFieldDataType(column.dataType))).toList
    val targetSchema: StructType = StructType(targetFieldsSeq)
    targetSchema
  }

  def getTargetDF(actualSourceDF: Dataset[Row], mappingData: MappingData): Dataset[Row] = {

    //transform changes starts
    var sourceDF = actualSourceDF
    val targetColumnObjectList: Array[TargetColumn] = mappingData.targetColumns
    val targetFieldsList: Array[String] = targetColumnObjectList.map(f => f.name).toArray[String]

    val targetFieldsListWithSourceColumns: List[String] = targetColumnObjectList.filter(tc => tc.sourceColumn != null).map(tc => tc.name).toList
    val targetSchema: StructType = SparkUtils.buildTargetSchema(mappingData)
    targetSchema.fields.foreach(field => {
      val targetFieldName: String = field.name;
      if (!targetFieldsListWithSourceColumns.contains(targetFieldName)) {
        sourceDF = sourceDF.withColumn(targetFieldName, lit(null).cast(field.dataType))
      }
    })
    //transform changes ends
    val exprs: Seq[String] = targetColumnObjectList.map(a => {
      if (a.transform == null || a.transform == "")
        a.name
      else
        a.transform + " as " + a.name
    }).toSeq

    println(exprs)

    sourceDF = sourceDF.selectExpr(exprs: _*)

    var columnsList: List[Column] = Nil
    targetSchema.fields.foreach(field => {
      columnsList = columnsList ::: List(sourceDF.col(field.name).cast(field.dataType))
    })
    val targetDF = sourceDF.select(columnsList: _*)
    targetDF
  }

  def getJdbcTableDF(spark: SparkSession, mappingData: MappingData): Dataset[Row] = {

    val tableSchema: String = mappingData.tableSchema
    val tableName: String = mappingData.tableName
    val tableDF = SparkUtils.getJdbcTableDF(spark, tableSchema, tableName)
    tableDF
  }

  def getJdbcTableDF(spark: SparkSession, tableSchema: String, tableName: String): Dataset[Row] = {
    val jdbcSchema: String = "\"" + tableSchema + "\""
    val jdbcTableName: String = "\"" + tableName + "\""
    val qualifiedJdbcTableName: String = s"$jdbcSchema.$jdbcTableName"
    println(s"jdbcSchema=$jdbcSchema")
    println(s"jdbcTableName=$jdbcTableName")
    println(s"qualifiedJdbcTableName=$qualifiedJdbcTableName")
    //spark JDBC code from here 
    val tableDF = spark.read.jdbc(PropertyUtils.getProperty("jdbcURL"), qualifiedJdbcTableName, JdbcAppUtils.getConnectionProperties)
    tableDF
  }

  def getJdbcTableDF(spark: SparkSession, customTableQuery: String): Dataset[Row] = {
    println(s"customTableQuery=$customTableQuery")
    //spark JDBC code from here 
    val tableDF = spark.read.jdbc(PropertyUtils.getProperty("jdbcURL"), customTableQuery, JdbcAppUtils.getConnectionProperties)
    tableDF
  }

  def insertDFToJdbcTarget(toBeInsertedDF: Dataset[Row], mappingData: MappingData): Long = {

    val tableSchema: String = mappingData.tableSchema
    val tableName: String = mappingData.tableName

    //println(s"toBeInsertedDF to be inserted into table $tableName")
    //toBeInsertedDF.show()

    val jdbcSchema: String = "\"" + tableSchema + "\""
    val jdbcTableName: String = "\"" + tableName + "\""
    val count: Long = toBeInsertedDF.count()
    if (count > 0) {
      println(s"Now inserting data to the table : $jdbcTableName")
      toBeInsertedDF.write
        .mode(SaveMode.Append)
        .jdbc(PropertyUtils.getProperty("jdbcURL"), s"$jdbcSchema.$jdbcTableName", JdbcAppUtils.getConnectionProperties)
      println(s"Data saved to the table : $jdbcTableName successfully!")
    }
    count
  }

  def getFieldDataType(dbDataType: String): DataType = {
    dbDataType.toUpperCase() match {
      case "INT" | "INT4" | "SMALLINT" | "SERIAL" | "INTEGER" => DataTypes.IntegerType
      case "CHAR" | "VARCHAR" | "TEXT" => DataTypes.StringType
      case "FLOAT" => DataTypes.FloatType
      case "REAL" | "FLOAT8" => DataTypes.DoubleType
      case "DATE" | "TIME" | "TIMESTAMP" => DataTypes.TimestampType
      case _ => DataTypes.StringType
    }
  }

  def repartitionData(inputDF: Dataset[Row], mappingData: MappingData): Dataset[Row] = {
    val numPartitions: Int = PropertyUtils.getProperty("partitionCount").toInt
    val primaryKey: String = mappingData.primaryKey
    val primaryKeys: Array[String] = mappingData.primaryKeys
    val partitionColumn: String = if (primaryKey != null) primaryKey else primaryKeys(0)
    val partitionedDF: Dataset[Row] = inputDF.repartition(numPartitions, inputDF.col(partitionColumn))
    //partitionedDF.show()
    partitionedDF
  }

  def combineMultipleSources(spark: SparkSession, baseSourceDF: Dataset[Row], targetName: String, mappingData: MappingData): Dataset[Row] = {
    var sourceDF: Dataset[Row] = baseSourceDF
    if (mappingData.sourceList.length > 1) {
      val parts: Array[String] = targetName.split("_")
      val sourceNamePrefix: String = parts(0) + "_" + parts(1) + "_"
      val sourceList: Array[String] = mappingData.sourceList
      val primarySource: String = mappingData.primarySource
      val primarySourceKey: String = mappingData.primarySourceKey
      sourceList.filter(source => source != primarySource).foreach(source => {
         val s3SourcesList: List[String] = S3Util.getS3MatchingFileKeys(
                                                    PropertyUtils.getProperty("sourceDataBucketName"),
                                                    PropertyUtils.getProperty("sourceDataFolderKey") + "/" + source,
                                                    ".dat"
                                                 )
          var nextS3CombinedSourceDF = SparkUtils.createEmptyDataframe(spark, targetName, source)
          for (s3SourceFileNameKey <- s3SourcesList) {
            val s3SourceFileName: String = s3SourceFileNameKey.replaceFirst(PropertyUtils.getProperty("sourceDataFolderKey") + "/", "")
            println("Processing source file : " + s3SourceFileName)
            var s3SourceDF = SparkUtils.getSourceDF(spark, targetName, source, s3SourceFileName)
            println("Displaying sourceDF from S3 for source: "+source)
            s3SourceDF.show()
            // pick rejectDFs and check for any matching records
            SparkUtils.checkAndProcessPreviousRejectedRecords(spark, targetName, source, s3SourceDF)
            val rejectDF = SparkUtils.getDataTypeMismatchRecords(s3SourceDF, mappingData)
            SparkUtils.uploadRejectRecordsToS3(rejectDF, targetName, mappingData.primarySource, s3SourceFileName)
            //rejectDF.show()
            s3SourceDF = s3SourceDF.except(rejectDF)
            nextS3CombinedSourceDF = nextS3CombinedSourceDF.union(s3SourceDF)
            //sourceDF.show()
          }
        val nextSourceRefKey: String = source + "__" + primarySourceKey
        val sourceRefKey: String = primarySource + "__" + primarySourceKey
        sourceDF = sourceDF.join(nextS3CombinedSourceDF, sourceDF.col(sourceRefKey) === nextS3CombinedSourceDF.col(nextSourceRefKey), "left_outer")
        //println(s"After joining with source $source")
        //sourceDF.show()
      })
    }
    sourceDF
  }

  def combineTableSources(spark: SparkSession, baseSourceDF: Dataset[Row], mappingData: MappingData): Dataset[Row] = {
    var sourceDF: Dataset[Row] = baseSourceDF
    val sourceTableList: Array[SourceTableObject] = mappingData.sourceTableList
    if (sourceTableList != null && sourceTableList.length > 0) {
      for (sourceTableobject <- sourceTableList) {
        val sourceTableName: String = sourceTableobject.tableName
        val customTableQuery: String = JdbcAppUtils.createCustomTableQuery(mappingData.tableSchema, sourceTableobject)
        val sourceTableDF = SparkUtils.getJdbcTableDF(spark, customTableQuery).alias(sourceTableName)
        //println("sourceDF to be combined as base")
        //sourceDF.show()
        //println("sourceTableDF to be combined")
        //sourceTableDF.show()
        val joinSourceColumn = sourceTableobject.joinSourceColumn
        val joinTableColumn = sourceTableobject.joinTableColumn
        sourceDF = sourceDF.join(sourceTableDF, sourceDF.col(joinSourceColumn) === sourceTableDF.col(joinTableColumn), "inner")
        //println("sourceDF after joining with \"" + sourceTableName + " \"table")
        //sourceDF.show()
      }
    }
    sourceDF
  }

  def addSourceNameColumnToDF(spark: SparkSession, baseSourceDF: Dataset[Row], sourceName: String, mappingData: MappingData): Dataset[Row] = {
    var sourceDF: Dataset[Row] = baseSourceDF
    val sourceSystemName: String = mappingData.addSourceNameColumn
    if (sourceSystemName != null) {
      sourceDF = sourceDF.withColumn(mappingData.addSourceNameColumn, lit(sourceName).cast(DataTypes.StringType))
      println("added sourceName column")
      //sourceDF.show()
    }
    sourceDF
  }
  // Added for rejecting data based on DataType mismatch starts

  def getSparkDataType(fieldName: String, fieldsWithDataTypes: List[(String, DataType)]): DataType = {
    val list = fieldsWithDataTypes.filter(a => a._1 == fieldName).map(a => a._2).toList
    if (list != null && list.size == 1) {
      list(0)
    } else {
      StringType
    }
  }

  def getDataTypeMismatchRecords(baseSourceDF: Dataset[Row], mappingData: MappingData): Dataset[Row] = {

    val fieldsWithDataTypes: List[(String, DataType)] = mappingData.targetColumns.map(tc => (tc.sourceColumn, getFieldDataType(tc.dataType))).toList
    val fields: Array[StructField] = baseSourceDF.schema.fields
    val rejectDF = baseSourceDF.filter(row => {
      var skipRow = false
      try {
        fields.foreach(field => {
          val dataType: DataType = getSparkDataType(field.name, fieldsWithDataTypes)
          val value: Any = row.get(row.fieldIndex(field.name))
          dataType match {
            case DataTypes.IntegerType => value.toString().toInt
            case DataTypes.LongType => value.toString().toLong
            case DataTypes.FloatType => value.toString().toFloat
            case DataTypes.DoubleType => value.toString().toDouble
            case DataTypes.StringType => value.toString()
            case _ => value.toString()
          }
        })
      } catch {
        case e: Exception => {
          skipRow = true
        }
      }
      skipRow
    })
    rejectDF
  }
  // Added for rejecting data based on DataType mismatch ends

  def saveDataFrameToCSV(df: Dataset[Row], targetFolderPath: String, targetFileName: String): Boolean = {
    val targetFile: File = new File(targetFolderPath + "/" + targetFileName)
    if (targetFile.exists()) {
      targetFile.delete()
    }
    val timestamp: String = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss-SSS"))
    val tempFolderPath: String = targetFolderPath + "/tmp/" + timestamp
    val tempFileName: String = tempFolderPath + "/" + targetFileName
    df.coalesce(1).write.option("delimiter", "|").mode(SaveMode.Overwrite).csv(tempFolderPath)
    val tempFolder: File = new File(tempFolderPath)
    var tempFile: File = null
    tempFolder.listFiles().foreach(f => {
      if (f.getName.endsWith(".csv")) {
        tempFile = new File(tempFileName)
        f.renameTo(tempFile)
      } else {
        f.delete()
      }
    })
    if (tempFile != null && tempFile.exists()) {
      tempFile.renameTo(targetFile)
      FileUtils.deleteDirectory(tempFolder.getParentFile.getAbsolutePath)
    }
    targetFile.exists()
  }

  def uploadRejectRecordsToS3(rejectDF:Dataset[Row], targetName:String, actualSourceName:String, s3SourceFileName:String):Boolean={
          val sourceSystemName = NamesUtil.getSourceSystemName(targetName)
          val s3SourceFileTimestamp: String = DateTimeUtil.getFileTimestampString(s3SourceFileName)
          println("Got source file timestamp: " + s3SourceFileTimestamp)
          val rejectFolderPath: String = PropertyUtils.getProperty("localRejectFolderPath")
          val rejectFileName: String = sourceSystemName+"_"+actualSourceName + "_" + s3SourceFileTimestamp + ".reject"
          val rejectFile: File = new File(rejectFolderPath + "/" + rejectFileName)
          if (rejectDF.count() > 0) {
            val isSaved: Boolean = SparkUtils.saveDataFrameToCSV(rejectDF, rejectFolderPath, rejectFileName)
            if (isSaved) {
              val isUploaded: Boolean = S3Util.uploadFile(
                PropertyUtils.getProperty("rejectDataBucketName"),
                PropertyUtils.getProperty("rejectDataFolderKey") + "/" + rejectFileName,
                rejectFile.getAbsolutePath)
              println("Reject file upload done ? " + isUploaded)
              if (isUploaded) {
                rejectFile.delete()
              }
            }
          }
    true
  }
  
}