package com.fidelity.s3process.util

import java.io.BufferedReader
import java.io.File
import java.io.FileReader

object FileUtils {
  def main(args: Array[String]): Unit = {
    val a:Array[String] = Array("a", "b", "c", "d")
    Array.tabulate(a.length){ i => (a(i),i+1) }.foreach(t=>println(t._2))
    Array.tabulate(a.length){ i => (a(i),i+101) }.foreach(t=>println(t._2))
    Array.tabulate(a.length){ i => (a(i),i+201) }.foreach(t=>println(t._2))
    Array.tabulate(a.length){ i => (a(i),i+301) }.foreach(t=>println(t._2))
  }
  
  def getJsonString(fileName:String):String={

     val fileReader : FileReader = new FileReader(fileName)
     val reader:BufferedReader =new BufferedReader(fileReader)
     var jsonString:StringBuilder = new StringBuilder()
     var line:String = reader.readLine()
     while(line!=null){
       jsonString.append(line)
       jsonString.append(System.lineSeparator())
       line= reader.readLine()
     }
     reader.close()
     jsonString.toString()
   }
  
  def createFileIfNotExists(fileName:String):Boolean={
    println(fileName)
     val file:File = new File(fileName)
     if(!file.exists()){
       if(!file.getParentFile.exists()){
         file.getParentFile.mkdirs()
       }
       file.createNewFile()
     }
     file.exists()
  }
  
  def createFolderIfNotExists(folderName:String):Boolean={
     val folder:File = new File(folderName)
     if(!folder.exists()){
       folder.mkdirs()
     }
     folder.exists() && folder.isDirectory()
  }
  
  def deleteDirectory(folderPath:String):Boolean={
    val folder:File = new File(folderPath)
    org.apache.commons.io.FileUtils.deleteDirectory(folder)
    !folder.exists()
  }
  
  
  
}