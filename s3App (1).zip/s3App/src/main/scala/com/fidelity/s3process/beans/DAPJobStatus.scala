package com.fidelity.s3process.beans

class DAPJobStatus {
  var sourceSystemID:Int =_
  var sourceType:String =_
  var sourceItem:String =_
  var jobType:String =_
  var lastRunTimestamp:String =_
  var jobStatus:String =_
}
    
  
  