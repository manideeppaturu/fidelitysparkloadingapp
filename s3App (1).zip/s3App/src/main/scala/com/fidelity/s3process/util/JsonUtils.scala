package com.fidelity.s3process.util

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import java.time.LocalDateTime
import java.lang.reflect.Type
import scala.collection.mutable.HashMap
import org.apache.log4j.Logger
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType

object JsonUtils {
  
	val log:Logger = Logger.getLogger(JsonUtils.getClass)
  val gson:Gson = new GsonBuilder().setPrettyPrinting().create()
  
  // TargetList json parsing
  case class Item(val sourceName:String, val sourceType:String, val itemList:Array[String]) 
  case class Target(val target:Array[Item]) 
  
  def getTargetList(jsonString:String):Array[String]={
	  
	  val targets:Target = gson.fromJson(jsonString, classOf[Target])
	  val items: List[Item] = targets.target.toList
	  val actualTargetList:Array[String] = items.flatMap(item=>{
                                                      	      val sourceName: String = item.sourceName
                                                      	      val sourceType: String = item.sourceType
                                                      	      item.itemList.map(sourceFile=>sourceName+"_"+sourceType+"_"+sourceFile)
	                                                         }
	                                                   ).toArray
    actualTargetList
	}
  
  // MetaData json parsing
  case class MetaData(val source:String, val columns:Array[String])
  
  def getMetaDataMap(jsonString:String):HashMap[Int,String]={
    
    val indexMap:HashMap[Int,String] = new HashMap[Int,String]()
    val metaData:MetaData = gson.fromJson(jsonString, classOf[MetaData])
    log.info("Metadata source from JSON is : "+metaData.source)
    val columns:Array[String] = metaData.columns
    Array.tabulate(columns.length){ i => (i, columns(i)) }.foreach(a=>indexMap.put(a._1.toInt, a._2.toString()))
    indexMap
  }
	
  // Mapping json parsing
  case class MappingData(
                         val operation:String,
                         val tableSchema:String,
                         val tableName:String,
                         val primaryKey:String,
                         val primaryKeys:Array[String],
                         val sourceList:Array[String],
                         val primarySource:String,
                         val primarySourceKey:String,
                         val addSourceNameColumn:String,
                         val sourceTableList:Array[SourceTableObject],
                         val targetColumns:Array[TargetColumn]
                        )
  
  case class SourceTableObject(
                                val tableName:String,
                                val loadColumns:Array[String],
                                val joinTableColumn:String,
                                val joinSourceColumn:String
                              )
                         
  case class TargetColumn(
                          val name:String,
                          val dataType:String,
                          val sourceColumn:String,
                          val transform:String
                         )
  
  def getMappingData(jsonString:String):MappingData={
    
    val mappingData:MappingData = gson.fromJson(jsonString, classOf[MappingData])
    log.info("From mappingData p(operationType)= : "+mappingData.operation)
    log.info("From mappingData primaryKey= : "+mappingData.primaryKey)
    mappingData
  }
 
  case class ReferenceMappingData(
                                    tableName:String,
                                    sourceRefKey:String,
                                    childTableName:String,
                                    childTableRefKey:String,
                                    childTablePrimaryKey:String,
                                    pushTable:String,
                                    pushTableRefKey:String,
                                    dbSeqName:String
                                  ) 
 
  def getReferenceMappingData(jsonString:String):ReferenceMappingData={
    
    val referenceMappingData:ReferenceMappingData = gson.fromJson(jsonString, classOf[ReferenceMappingData])
    referenceMappingData
  }
  
}