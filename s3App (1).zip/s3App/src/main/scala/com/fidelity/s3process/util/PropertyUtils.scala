package com.fidelity.s3process.util

import org.apache.log4j.Logger
import java.util.Properties
import java.io.InputStream
import java.io.IOException
import org.apache.log4j.Level

object PropertyUtils {
	
	private val log:Logger= Logger.getLogger(PropertyUtils.getClass)
	private var props:Properties = new Properties()
	
	
	def initProperties(filePath:String):Unit={
		try {
				val inputStream:InputStream = PropertyUtils.getClass.getClassLoader().getResourceAsStream(filePath);
				
				//loading properties object with input stream of property file
				props.load(inputStream)
		} 
		catch  {
		  case ioe: IOException  =>  ioe.printStackTrace()
		  case e: Exception  => e.printStackTrace()
		}
	}
	
def getProperty(key:String):String={
		val value:String = props.getProperty(key)
		if(value==null) return ""
		else return value
	}

}